# Project Management System

## Overview

This is a Flask-based project management web application that allows users to create accounts, manage projects, and track tasks. The application uses an in-memory database for data persistence and follows a traditional server-side rendered architecture with Bootstrap for styling.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Server-Side Rendering**: Uses Flask's Jinja2 templating engine for dynamic HTML generation
- **CSS Framework**: Bootstrap 5 with dark theme and Bootstrap Icons
- **JavaScript**: Vanilla JavaScript for client-side interactions and form validation
- **Responsive Design**: Mobile-first approach using Bootstrap's grid system

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Session Management**: Flask sessions with server-side session storage
- **Authentication**: Token-based authentication using UUIDs stored in memory
- **Data Storage**: In-memory Python dictionaries (temporary solution)
- **Routing**: RESTful-style routes for web pages with form-based interactions

### Data Storage
- **Current Solution**: In-memory dictionaries for users, tokens, projects, and tasks
- **Data Models**:
  - Users: username and password
  - Tokens: UUID tokens mapped to usernames
  - Projects: name, owner, and task lists
  - Tasks: title, status, assigned user, and project association

## Key Components

### Authentication System
- User registration and login functionality
- Session-based authentication with token generation
- Password storage in plain text (development only)
- Authentication helpers for protected routes

### Project Management
- Create and view projects
- Project ownership model
- Task organization within projects
- Dashboard view for project overview

### Task Management
- Task creation with title and assignment
- Task status tracking (todo, in-progress, done)
- Task detail views
- Kanban-style organization (partial implementation)

### User Interface
- Responsive web interface using Bootstrap
- Modal dialogs for creating projects and tasks
- Navigation bar with authentication state
- Alert system for user feedback

## Data Flow

1. **User Registration/Login**: Form submission → Flask route → User creation/validation → Session token generation
2. **Project Creation**: Authenticated request → Project creation → Database storage → Redirect to dashboard
3. **Task Management**: Project context → Task creation → Status updates → Project view refresh
4. **Authentication Flow**: Session token validation → User context → Protected route access

## External Dependencies

### Frontend Dependencies
- Bootstrap 5 CSS Framework (CDN)
- Bootstrap Icons (CDN)
- Bootstrap JavaScript components

### Backend Dependencies
- Flask web framework
- Python standard library (uuid, logging, os)
- No external database dependencies (uses in-memory storage)

## Deployment Strategy

### Current Setup
- Development server using Flask's built-in server
- Environment variable support for session secrets
- Debug mode enabled for development
- Host configuration for container deployment (0.0.0.0:5000)

### Considerations for Production
- **Database Migration**: The in-memory storage needs to be replaced with a persistent database (PostgreSQL recommended)
- **Authentication Security**: Password hashing and secure session management required
- **Static File Serving**: Production web server for static assets
- **Environment Configuration**: Proper environment variable management for different deployment stages

### Missing Production Features
- Database persistence
- Password hashing and security
- HTTPS configuration
- Error handling and logging
- Input validation and sanitization
- API rate limiting
- Backup and recovery procedures

The application is currently in a development state with basic functionality implemented but requires significant security and persistence improvements for production use.