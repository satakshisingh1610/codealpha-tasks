import os
import uuid
import logging
from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

# Simulated in-memory database
users = {}
tokens = {}
projects = {}
tasks = {}

# Helper function to get current user
def get_current_user():
    token = session.get('token')
    return tokens.get(token) if token else None

# Helper function to require authentication
def require_auth():
    if not get_current_user():
        flash('Please log in to access this page.', 'error')
        return redirect(url_for('login'))
    return None

# Web Routes
@app.route('/')
def index():
    user = get_current_user()
    if user:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return render_template('signup.html')
    
    data = request.form
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        flash('Username and password are required.', 'error')
        return render_template('signup.html')
    
    if username in users:
        flash('User already exists. Please choose a different username.', 'error')
        return render_template('signup.html')
    
    users[username] = {'password': password}
    flash('Signup successful! Please log in.', 'success')
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    data = request.form
    username = data.get('username')
    password = data.get('password')
    
    user = users.get(username)
    if not user or user['password'] != password:
        flash('Invalid credentials. Please try again.', 'error')
        return render_template('login.html')
    
    token = str(uuid.uuid4())
    tokens[token] = username
    session['token'] = token
    flash('Login successful!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    token = session.get('token')
    if token and token in tokens:
        del tokens[token]
    session.pop('token', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    user = get_current_user()
    user_projects = {pid: proj for pid, proj in projects.items() if proj['owner'] == user}
    user_tasks = {tid: task for tid, task in tasks.items() if task['assigned_to'] == user}
    
    return render_template('dashboard.html', 
                         projects=user_projects, 
                         tasks=user_tasks,
                         username=user)

@app.route('/project/<project_id>')
def project_view(project_id):
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    project = projects.get(project_id)
    if not project:
        flash('Project not found.', 'error')
        return redirect(url_for('dashboard'))
    
    project_tasks = {tid: tasks[tid] for tid in project['tasks'] if tid in tasks}
    
    return render_template('project.html', 
                         project=project, 
                         project_id=project_id,
                         tasks=project_tasks)

@app.route('/task/<task_id>')
def task_view(task_id):
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    task = tasks.get(task_id)
    if not task:
        flash('Task not found.', 'error')
        return redirect(url_for('dashboard'))
    
    project = projects.get(task['project_id'])
    
    return render_template('task.html', 
                         task=task, 
                         task_id=task_id,
                         project=project)

@app.route('/create_project', methods=['POST'])
def create_project():
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    user = get_current_user()
    name = request.form.get('name')
    
    if not name:
        flash('Project name is required.', 'error')
        return redirect(url_for('dashboard'))
    
    project_id = str(uuid.uuid4())
    projects[project_id] = {
        'name': name,
        'owner': user,
        'tasks': []
    }
    flash('Project created successfully!', 'success')
    return redirect(url_for('project_view', project_id=project_id))

@app.route('/create_task', methods=['POST'])
def create_task():
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    user = get_current_user()
    title = request.form.get('title')
    project_id = request.form.get('project_id')
    assigned_to = request.form.get('assigned_to', user)
    
    if not title or not project_id:
        flash('Task title and project are required.', 'error')
        return redirect(url_for('dashboard'))
    
    if project_id not in projects:
        flash('Project not found.', 'error')
        return redirect(url_for('dashboard'))
    
    task_id = str(uuid.uuid4())
    task = {
        'title': title,
        'project_id': project_id,
        'assigned_to': assigned_to,
        'status': 'todo',
        'comments': []
    }
    tasks[task_id] = task
    projects[project_id]['tasks'].append(task_id)
    flash('Task created successfully!', 'success')
    return redirect(url_for('project_view', project_id=project_id))

@app.route('/update_task_status', methods=['POST'])
def update_task_status():
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    task_id = request.form.get('task_id')
    status = request.form.get('status')
    
    if not task_id or not status:
        flash('Task ID and status are required.', 'error')
        return redirect(url_for('dashboard'))
    
    task = tasks.get(task_id)
    if not task:
        flash('Task not found.', 'error')
        return redirect(url_for('dashboard'))
    
    task['status'] = status
    flash('Task status updated successfully!', 'success')
    return redirect(url_for('task_view', task_id=task_id))

@app.route('/add_comment', methods=['POST'])
def add_comment():
    auth_check = require_auth()
    if auth_check:
        return auth_check
    
    user = get_current_user()
    task_id = request.form.get('task_id')
    comment_text = request.form.get('comment')
    
    if not task_id or not comment_text:
        flash('Task ID and comment text are required.', 'error')
        return redirect(url_for('dashboard'))
    
    task = tasks.get(task_id)
    if not task:
        flash('Task not found.', 'error')
        return redirect(url_for('dashboard'))
    
    comment = {'by': user, 'text': comment_text}
    task['comments'].append(comment)
    flash('Comment added successfully!', 'success')
    return redirect(url_for('task_view', task_id=task_id))

# API Routes (for potential future API usage)
@app.route('/api/signup', methods=['POST'])
def api_signup():
    data = request.json
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'msg': 'Username and password are required'}), 400
    
    if data['username'] in users:
        return jsonify({'msg': 'User already exists'}), 400
    
    users[data['username']] = {'password': data['password']}
    return jsonify({'msg': 'Signup successful'}), 200

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'msg': 'Username and password are required'}), 400
    
    user = users.get(data['username'])
    if not user or user['password'] != data['password']:
        return jsonify({'msg': 'Invalid credentials'}), 401
    
    token = str(uuid.uuid4())
    tokens[token] = data['username']
    return jsonify({'msg': 'Login successful', 'token': token}), 200

@app.route('/api/projects', methods=['GET'])
def api_get_projects():
    token = request.headers.get('Authorization')
    user = tokens.get(token)
    if not user:
        return jsonify({'msg': 'Unauthorized'}), 401
    
    return jsonify(projects), 200

@app.route('/api/tasks', methods=['GET'])
def api_get_tasks():
    token = request.headers.get('Authorization')
    user = tokens.get(token)
    if not user:
        return jsonify({'msg': 'Unauthorized'}), 401
    
    return jsonify(tasks), 200

@app.route('/api/task/<task_id>', methods=['GET'])
def api_get_single_task(task_id):
    token = request.headers.get('Authorization')
    user = tokens.get(token)
    if not user:
        return jsonify({'msg': 'Unauthorized'}), 401
    
    task = tasks.get(task_id)
    if not task:
        return jsonify({'msg': 'Task not found'}), 404
    
    return jsonify(task), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
